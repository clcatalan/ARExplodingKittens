The supplied private key is for your usage only and allows you to generate certificates to sign applications that are associated with your Magic Leap Identity. 

Be sure to securely store your private key as it is not stored on any Magic leap server. Magic Leap does not have access to your private key, including during generation. 

If your private key is exposed or compromised in any way, be sure to invalidate your certificate and create a new one. 

For more information, visit creator.magicleap.com